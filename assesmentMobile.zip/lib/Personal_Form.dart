import 'package:flutter/material.dart';

class PersonalDetails extends StatefulWidget {
  final String? name;
  final String? email;
  final String? nomer;
  final String? personalID;
  final String? address;
  final String? date;

  PersonalDetails({
    this.name,
    this.email,
    this.nomer,
    this.personalID,
    this.address,
    this.date,
  });

  @override
  _PersonalDetailsState createState() => _PersonalDetailsState();
}

class _PersonalDetailsState extends State<PersonalDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail'),
        backgroundColor:
            Colors.white, // Ganti latar belakang Appbar menjadi putih
        iconTheme: IconThemeData(
            color: Colors.black), // Ganti warna ikon Appbar menjadi hitam
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailItem("Nama", widget.name),
            _buildDetailItem("Email", widget.email),
            _buildDetailItem("Nomor Telepon", widget.nomer),
            _buildDetailItem("Personal ID", widget.personalID),
            _buildDetailItem("Alamat", widget.address),
            _buildDetailItem("Tanggal", widget.date),
          ],
        ),
      ),
      backgroundColor:
          Colors.white, // Ganti latar belakang Scaffold menjadi putih
    );
  }

  Widget _buildDetailItem(String label, String? value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black, // Ganti warna teks menjadi hitam
          ),
        ),
        SizedBox(height: 4),
        Text(
          value ?? 'N/A',
          style: TextStyle(
            fontSize: 16,
            color: Colors.black, // Ganti warna teks menjadi hitam
          ),
        ),
        SizedBox(height: 16),
      ],
    );
  }
}

class PersonalForm extends StatefulWidget {
  const PersonalForm({Key? key}) : super(key: key);

  @override
  _PersonalFormState createState() => _PersonalFormState();
}

class _PersonalFormState extends State<PersonalForm> {
  final _nameTextboxController = TextEditingController();
  final _emailTextboxController = TextEditingController();
  final _nomerTextboxController = TextEditingController();
  final _PersonalIDTextboxController = TextEditingController();
  final _AddressTextboxController = TextEditingController();
  final _dateTextboxController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'PERSONAL FORM',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            _formName(),
            _formEmail(),
            _formNomer(),
            _formPersonalID(),
            _formAddress(),
            _formDate(),
            _tombolSimpan(),
          ],
        ),
      ),
      backgroundColor:
          Colors.white, // Ganti latar belakang Scaffold menjadi putih
    );
  }

  _formName() {
    return Container(
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.blue),
        color: Colors.white, // Set latar belakang menjadi putih
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(
                0.5), // Warna shadow (warna abu-abu dengan tingkat transparansi 0.5)
            spreadRadius: 3, // Seberapa jauh shadow akan menyebar
            blurRadius: 5, // Seberapa blur shadow
            offset: Offset(0, 3), // Posisi shadow (x, y)
          ),
        ],
      ),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: "Full Name",
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        ),
        controller: _nameTextboxController,
        style: TextStyle(
            fontSize: 16, color: Colors.black), // Set warna teks menjadi hitam
      ),
    );
  }

  _formEmail() {
    return Container(
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.blue),
      ),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: "Email",
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        ),
        controller: _emailTextboxController,
        style: TextStyle(fontSize: 16, color: Colors.black),
      ),
    );
  }

  _formNomer() {
    bool isVerified = _nomerTextboxController
        .text.isNotEmpty; // Periksa apakah nomor sudah diisi

    return Container(
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.blue),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: TextFormField(
                decoration: InputDecoration(
                  labelText: "Nomor Phone",
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 15),
                ),
                controller: _nomerTextboxController,
                style: TextStyle(fontSize: 16, color: Colors.black),
              ),
            ),
          ),
          SizedBox(width: 8),
          ElevatedButton(
            onPressed: isVerified
                ? () {
                    // Lakukan sesuatu setelah tombol verifikasi ditekan
                  }
                : null, // Tidak menjalankan aksi apa pun jika tidak diverifikasi
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all(Colors.blue),
              padding: MaterialStateProperty.all(
                EdgeInsets.only(left: 12, right: 12, top: 16, bottom: 16),
              ),
              shape: MaterialStateProperty.all(RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              )),
            ),
            child: Text(
              isVerified ? 'Terverifikasi' : 'Verifikasi',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  _formPersonalID() {
    return Container(
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.blue),
      ),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: "Personal ID",
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        ),
        controller: _PersonalIDTextboxController,
        style: TextStyle(fontSize: 16, color: Colors.black),
      ),
    );
  }

  _formAddress() {
    return Container(
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.blue),
      ),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: "Address",
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        ),
        controller: _AddressTextboxController,
        style: TextStyle(fontSize: 16, color: Colors.black),
      ),
    );
  }

  _formDate() {
    return Container(
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.blue),
      ),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: "Date",
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        ),
        controller: _dateTextboxController,
        style: TextStyle(fontSize: 16, color: Colors.black),
      ),
    );
  }

  _tombolSimpan() {
    return ElevatedButton(
      onPressed: () {
        String name = _nameTextboxController.text;
        String email = _emailTextboxController.text;
        String nomer = _nomerTextboxController.text;
        String personalID = _PersonalIDTextboxController.text;
        String address = _AddressTextboxController.text;
        String date = _dateTextboxController.text;

        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => PersonalDetails(
            name: name,
            email: email,
            nomer: nomer,
            personalID: personalID,
            address: address,
            date: date,
          ),
        ));
      },
      child: const Text('Simpan'),
    );
  }
}
