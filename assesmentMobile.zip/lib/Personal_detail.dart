import 'package:flutter/material.dart';

class PersonalDetail extends StatefulWidget {
  final String? name;
  final String? email;
  final String? nomer;
  final String? personalID;
  final String? address;
  final String? date;

  PersonalDetail({
    this.name,
    this.email,
    this.nomer,
    this.personalID,
    this.address,
    this.date,
  });

  @override
  _PersonalDetailState createState() => _PersonalDetailState();
}

class _PersonalDetailState extends State<PersonalDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailItem("Nama", widget.name),
            _buildDetailItem("Email", widget.email),
            _buildDetailItem("Nomor Telepon", widget.nomer),
            _buildDetailItem("Personal ID", widget.personalID),
            _buildDetailItem("Alamat", widget.address),
            _buildDetailItem("Tanggal", widget.date),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String? value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 4),
        Text(
          value ?? 'N/A', // Tampilkan 'N/A' jika data tidak ada
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        SizedBox(height: 16),
      ],
    );
  }
}
