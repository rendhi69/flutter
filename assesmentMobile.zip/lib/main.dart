import 'package:flutter/material.dart';
import 'Personal_Form.dart';
import 'Personal_detail.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Personal Form App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // Tentukan halaman awal aplikasi
      initialRoute: '/form', // Ini adalah halaman formulir awal
      routes: {
        '/form': (context) => PersonalForm(), // Halaman formulir
        '/detail': (context) => PersonalDetail(), // Halaman detail
      },
    );
  }
}
